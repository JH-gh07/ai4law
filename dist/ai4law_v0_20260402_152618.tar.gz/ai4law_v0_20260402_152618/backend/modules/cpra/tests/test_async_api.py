import time

from fastapi.testclient import TestClient

from backend.main import app

client = TestClient(app)


def test_cpra_async_flow() -> None:
    accepted = client.post(
        "/api/v1/cpra/generate_async",
        json={
            "company_name": "AsyncCPRA",
            "business_model": "SaaS",
            "data_lifecycle": "收集-处理-存储-删除",
            "notice_and_consent": "隐私告知缺失",
            "consumer_rights_process": "目前仅邮箱接收",
            "opt_out_and_sale_sharing": "存在共享但无opt-out",
            "vendor_management": "供应商管理未体现DPA",
            "attachments": [
                {
                    "file_role": "privacy_policy",
                    "file_name": "policy.url",
                    "file_format": "url",
                    "storage_uri": "https://example.com/privacy",
                }
            ],
        },
    )
    assert accepted.status_code == 200
    task_id = accepted.json()["task_id"]

    for _ in range(60):
        status = client.get(f"/api/v1/cpra/tasks/{task_id}")
        assert status.status_code == 200
        payload = status.json()
        if payload["state"] == "COMPLETED":
            assert payload["result"]["output_files"]["xlsx"].endswith(".xlsx")
            return
        if payload["state"] == "FAILED":
            raise AssertionError(payload)
        time.sleep(0.05)

    raise AssertionError("cpra async task timeout")

